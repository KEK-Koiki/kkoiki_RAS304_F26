RAS304 SENSOR DESIGN - EK - TEAM 103

OPEN / USE
Extract the entire project ZIP, then open EK_Sensor103.kicad_pro in KiCad 10.0.7. Both custom libraries are project-local via sym-lib-table and fp-lib-table. Source files are genuine native KiCad files tested in KiCad 7.0.11 and use its forward-readable format. A direct 10.0.7 test has not been performed. Rerun ERC/DRC after opening and after any edits.

DESIGN
External regulated 5 V; MCP6004-I/P in 14-pin PDIP (7.62 mm row spacing, 2.54 mm pin pitch). R1 5.1k; R3/R4/R6/R7 10k; R5 100k. External photoresistor connected across J2 pins 1 (+5V) and 2 (SENSE). R1 connects SENSE to Earth. U1A buffers sensor voltage through R3 feedback, U1B applies gain -10 around 2.5 V reference. Unused amplifiers C/D are followers at VREF. C1 0.1uF bypasses U1 supply, C2 1uF ceramic provides local bulk capacitance.
Ideal linear VOUT = 27.5 - 10*V1, clipped near supply rails. Actual rail swing and optical response depend on sensor, load, tolerances, and device limits; no physical performance measurements are claimed.
J1: 1 +5V, 2 GND. J2: 1 +5V, 2 SENSE (LDR connects across J2). J3: 1 VOUT, 2 V1 (buffered sensor), 3 GND. Square pads identify pin 1. U1 notch / pin-1 end is toward the top of the assembly drawing. All parts mount on the top. Print Assembly_1to1.pdf at Actual Size / 100% and check components against it.

PCB / MILL RULES
80 x 65 mm, 2-layer FR4, 1.4986 mm board thickness, 17.5um (0.5 oz/ft2) copper each side. 0.508mm signal tracks, 1.016mm supply/ground tracks, 0.381mm clearance, 1.0mm copper-edge clearance. 0.8mm drill / 1.6mm diameter through vias. Actual component holes 0.8/0.9/1.0mm. Filled ground planes both sides. Large bold EK on top copper. No fabrication silkscreen. Mask layers included solely because the assignment lists them; manufacture without soldermask as assignment directs. Empty silkscreen layers supplied for completeness.
The normal sensor circuit current is far below 500mA. This is a sensor board, not a high-current power distribution board.
Peralta specification permits plated-through holes. This design requires through-connections at vias and through-hole pads; confirm your lab's process. If holes are not plated, fit via wires/rivets and solder relevant pads on both sides. Do not assume a bottom-only socket solder joint connects a top-layer trace on an unplated board.

VERIFICATION
- Native KiCad 7.0.11 successfully opened schematic and PCB.
- Schematic PDF and copper/assembly PDFs are native KiCad exports.
- Native exported schematic netlist matches all 37 physical board-pad net assignments, including all 14 IC pins (root-sheet slash prefix accounted for).
- KiCad native WriteDRCReport: 0 DRC violations, 0 unconnected pads, 0 footprint errors. No DRC exclusions.
- Board copper thickness, minimum rules, track widths and drills verified through board API / saved setup.
- Gerber RS-274X and inch-unit Excellon drill exported natively from final board.
- PDF visual review performed. Physical footprint fit and circuit operation have not been tested.

SUBMISSION PACKAGES
EK_Sensor103_Project.zip: complete editable project, symbol and footprint libraries, native schematic and PCB PDFs, DRC evidence/settings PDF, 1:1 assembly print, BOM and reports.
EK103.zip: separate Gerber/drill package using assignment filenames.
EK_Sensor103_Libraries.zip: third separate ZIP with updated symbol and footprint libraries and library tables.
EK103_Schematic_PCB.pdf: native schematic followed by top/bottom copper views.
EK103_DRC_Settings.pdf: genuine DRC results alongside plotted design, plus mill configuration details.

REMAINING SUBMISSION ACTIONS
1. Open in KiCad 10.0.7 and rerun checks. Capture PCB editor top/bottom screenshots and the DRC dialog alongside your design if the instructor requires GUI screenshots; the supplied PDFs are native plots and a documentary report, not GUI screenshots.
2. EK103.zip was uploaded to JLCDFM and PCB DFM analysis completed: 0 danger findings, 7 warnings, all Unconnected trace end on Top.art. Screenshot and captured results are included in EK103_JLCDFM_Results.pdf. Objects were reported as r39.3701 (1.0mm), consistent with the seven 1.0mm strokes forming EK copper initials. The site geometric viewer and PDF export stalled, so the warning locations could not be confirmed in the viewer; no warning-free DFM pass is claimed. Preserve the assignment's 0.5 oz / no-mask / no-silkscreen instructions regardless of generic fabrication previews.
3. Use your full name instead of EK in the Gerber ZIP filename if Canvas requires YourName103.zip; no full submission name was provided.
4. Submit the requested ZIPs and PDFs to Canvas yourself.

REFERENCE
Microchip MCP6001/R/U/2/4 data sheet DS20001733L; MCP6004-I/P PDIP pin map and package dimensions. User-supplied Sensor Design assignment, Resistive Amplifier lab and Peralta Mill Specs. Pin-name instruction mentioning the Curiosity Nano appears copied from the preceding assignment; this op-amp symbol uses the MCP6004 data sheet pin names.
