from pathlib import Path
import json,shutil
root=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26')
workspace=Path(__file__).resolve().parent
for src in (workspace/'repo-support').rglob('*'):
    if src.is_file():
        target=root/src.relative_to(workspace/'repo-support');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
record=json.loads((root/'data/bom/parts.json').read_text(encoding='utf-8'))
for filename,group in [('core.json','Core electronics'),('passives.json','Passives'),('interfaces.json','Connectors, protection & debug')]:
    parts=[p for p in record['parts'] if p['group']==group]
    for p in parts:p.pop('line_total',None)
    (root/'data/bom'/filename).write_text(json.dumps(parts,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(root/'data/bom/adapter.json').write_text(json.dumps(record['optional_adapter'],indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(root/'data/bom/metadata.json').write_text(json.dumps({k:v for k,v in record.items() if k not in ['parts','optional_adapter','subtotal']},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for src,dst in [('data/bom/parts.json','archive/development-history/parts-before-split.json'),('templates/components/cards.html','archive/development-history/cards-before-templates.html')]:
    a=(root/src).resolve();b=(root/dst).resolve()
    assert a.is_relative_to(root.resolve()) and b.is_relative_to(root.resolve())
    shutil.move(a,b)
check=(workspace/'verify_website.py').read_text(encoding='utf-8')
check='"""Check built page links, image targets, anchors and downloadable ZIPs.\n\nUsage: python tools/check_links.py [build-directory]\n"""\n'+check
check=check.replace('import zipfile,json','import zipfile,json,sys,re')
check=check.replace("root=Path(__file__).resolve().parent/'website-preview'", "root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'site'")
check=check.replace('errors=[];checked=0',"if not pages:raise SystemExit('No built HTML found; run python -m mkdocs build --strict first.')\nerrors=[];checked=0")
extra='''for css in root.rglob('*.css'):
 for target in re.findall(r'@import\\s+url\\([\\\"\\\']([^\\\"\\\']+)',css.read_text(encoding='utf-8')):
  checked+=1
  if not (css.parent/target).is_file():errors.append((str(css),'missing CSS import',target))
'''
check=check.replace('for p in root.rglob(\'*.zip\'):',extra+"for p in root.rglob('*.zip'):")
(root/'tools/check_links.py').write_text(check,encoding='utf-8')
(root/'package.json').write_text(json.dumps({'name':'team103-encoder-datasheet-tools','private':True,'type':'module','description':'Optional diagram export tool; MkDocs website builds only require Python.','scripts':{'diagram:export':'node tools/diagrams/export.mjs','diagram:check':'node tools/diagrams/export.mjs --check'},'devDependencies':{'sharp':'0.35.5'}},indent=2)+'\n',encoding='utf-8')
print('Installed portable focused tools and split purchasing catalogs.')
