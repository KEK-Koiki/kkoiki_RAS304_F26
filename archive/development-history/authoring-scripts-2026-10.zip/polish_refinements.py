from pathlib import Path
d=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26/docs')
p=d/'stylesheets/extra.css';t=p.read_text(encoding='utf-8')
t+='''\n/* Give detailed purchasing tables room while retaining tabs and section TOC. */
@media(min-width:76.25em){body:has(.bom-table) .md-sidebar--primary{display:none}body:has(.component-cards) .md-sidebar--primary{display:none}body:has(img[src*="encoder-detailed-block-diagram"]) .md-sidebar--primary{display:none}}
.bom-table table:not([class]) th{min-width:0}.bom-table td:nth-child(6){min-width:5rem}.bom-table td:nth-child(2){min-width:4rem}\n'''
p.write_text(t,encoding='utf-8')
# Update raw HTML source path convention in builder for any future regeneration.
print('Desktop table space refined without changing page order or navigation.')
