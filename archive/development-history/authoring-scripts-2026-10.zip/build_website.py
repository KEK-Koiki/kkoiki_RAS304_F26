from pathlib import Path
import shutil, sys, json, csv, zipfile, math
from collections import defaultdict
from PIL import Image, ImageDraw, ImageFont

workspace=Path(__file__).resolve().parent
repo=Path(sys.argv[1]) if len(sys.argv)>1 else workspace/'website'
source=workspace/'Encoder_Review'
docs=repo/'docs'
def write(path,text):
 p=repo/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def page(path,title,text):write('docs/'+path,'---\ntitle: '+title+'\n---\n\n'+text)
def copy(src,dst):
 p=docs/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)

write('mkdocs.yml','''
site_name: Elijah Koiki · RAS304
site_description: Team 103 motor encoder subsystem — design, components, schematics and verification.
site_url: https://kek-koiki.github.io/kkoiki_RAS304_F26/
repo_url: https://github.com/KEK-Koiki/kkoiki_RAS304_F26
repo_name: KEK-Koiki / kkoiki_RAS304_F26
edit_uri: edit/main/docs/
theme:
  name: material
  custom_dir: custom_theme/
  palette:
    primary: custom
    accent: custom
  font: false
  logo: static/encoder-mark.svg
  favicon: static/logo304.png
  features:
    - navigation.tabs
    - navigation.tabs.sticky
    - navigation.top
    - navigation.footer
    - content.action.edit
    - search.highlight
nav:
  - Overview: index.md
  - Block Diagram: 01-Block-Diagram/Block-Diagram.md
  - Component Selection: 02-Component-Selection/Component-Selection.md
  - BOM: 03-BOM/BOM.md
  - Schematic: 04-Schematic/schematic.md
  - Power Budget: 05-Power-Budget/Power-Budget.md
  - Review & Resources: Appendix/index.md
markdown_extensions:
  - attr_list
  - md_in_html
  - admonition
  - tables
  - toc:
      permalink: true
  - pymdownx.details
  - pymdownx.superfences
plugins:
  - search
  - glightbox
extra_css:
  - stylesheets/extra.css
exclude_docs: |
  static/node_modules/
  static/package*.json
  Appendix/another-subfile.md
  Appendix/basic-markdown-examples.md
  Appendix/charts.md
  Appendix/esp-32-table.md
  04-Schematic/dummyZip.zip
  04-Schematic/ExampleSchematic.pdf
  04-Schematic/Screenshot.png
  05-Power-Budget/PowerBudgetExample.pdf
  05-Power-Budget/PowerBudgetExample.xlsx
  05-Power-Budget/power-budject-new
copyright: Copyright &copy; 2026 Elijah Koiki · Team 103 · Arizona State University
extra:
  generator: false
''')
write('requirements.txt','mkdocs-material==9.8.0\nmkdocs-glightbox==0.5.3')
write('.gitignore','site/\n__pycache__/\n.venv/\n*.log\ndocs/static/node_modules/')
write('docs/static/encoder-mark.svg','''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="25" fill="none" stroke="#f6c45b" stroke-width="5" stroke-dasharray="8 5"/><circle cx="32" cy="32" r="12" fill="none" stroke="white" stroke-width="4"/><circle cx="32" cy="32" r="4" fill="white"/></svg>''')
write('docs/stylesheets/extra.css','''
:root{--md-primary-fg-color:#142c3c;--md-accent-fg-color:#157c83;--md-typeset-a-color:#116a73;--md-default-bg-color:#fafbf9}
body{font-family:"Segoe UI",Arial,sans-serif}.md-grid{max-width:1440px}.md-header{box-shadow:none;border-bottom:1px solid #ffffff1a}.md-tabs{background:#142c3c}.md-typeset{font-size:.82rem;line-height:1.75}.md-typeset h1{color:#142c3c;font-weight:750;letter-spacing:-.035em;margin-bottom:1rem}.md-typeset h2{font-weight:700;letter-spacing:-.02em;color:#142c3c;border-top:1px solid #dde5e7;padding-top:1.15rem}.md-typeset h3{font-weight:650}.md-typeset a{font-weight:550}.md-typeset table:not([class]){font-size:.71rem;border-radius:8px;overflow:hidden}.md-typeset table:not([class]) th{background:#e7eef0;color:#142c3c;min-width:5rem}.md-typeset table:not([class]) td{vertical-align:top}.md-typeset img{border-radius:10px}.md-typeset blockquote{border-color:#16868a;background:#edf5f3;padding:.7rem 1rem;color:#233e49}.eyebrow{font-size:.65rem;text-transform:uppercase;letter-spacing:.17em;font-weight:800;color:#9ee1d6}.hero{background:#142c3c;color:#f4f8f5;padding:2rem 2.2rem;border-radius:14px;margin-bottom:1.3rem;position:relative;overflow:hidden}.hero h1,.md-typeset .hero h1{font-size:2.65rem;line-height:1.08;color:white;margin:.65rem 0 1rem;max-width:700px}.hero p{max-width:650px;color:#d7e5e8}.hero .button{display:inline-block;background:#f6c45b;color:#142c3c!important;padding:.5rem 1rem;border-radius:5px;margin:.5rem .5rem 0 0;font-weight:750}.hero .button.secondary{background:#ffffff12;color:white!important;border:1px solid #ffffff40}.meta{display:flex;flex-wrap:wrap;gap:.5rem;margin:.9rem 0}.meta span{font-size:.64rem;padding:.25rem .7rem;border-radius:30px;background:#edf2f2;color:#34535e;font-weight:650}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.8rem;margin:1rem 0}.card{padding:1rem;border:1px solid #dbe5e5;border-radius:10px;background:white}.card .number{font-family:Consolas,monospace;color:#147b80;font-size:.65rem;letter-spacing:.1em}.card h3{margin:.4rem 0}.card p{font-size:.73rem;margin:.3rem 0}.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:.6rem;margin:1.2rem 0}.stat{padding:1rem;border-left:3px solid #e6b655;background:#edf2f2;border-radius:0 7px 7px 0}.stat b{display:block;color:#142c3c;font-size:1.3rem}.stat span{font-size:.65rem}.caption{font-size:.7rem;color:#58717a;margin-top:.4rem}.status{border:1px solid #dfc78c;background:#fcf6e8;border-radius:8px;padding:.8rem 1rem;font-size:.74rem}.md-typeset .admonition{font-size:.73rem}.md-footer{background:#142c3c}.md-footer-meta{background:#102330}.md-typeset code{border-radius:3px}.md-typeset .download{display:inline-block;border:1px solid #b5c9cb;border-radius:5px;padding:.35rem .7rem;margin:.2rem .3rem .2rem 0}
@media(max-width:900px){.cards{grid-template-columns:1fr 1fr}.hero{padding:1.5rem}.hero h1,.md-typeset .hero h1{font-size:2.1rem}.stat-grid{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.cards{grid-template-columns:1fr}.hero h1,.md-typeset .hero h1{font-size:1.8rem}.hero{padding:1.2rem}.md-typeset{font-size:.8rem}}
@media print{.md-header,.md-tabs,.md-sidebar,.md-footer,.md-top,.md-content__button{display:none!important}.md-main__inner{margin:0}.md-content{margin:0}.hero{background:white;color:#142c3c;border:1px solid #bbc}.hero p,.hero h1,.md-typeset .hero h1{color:#142c3c}.eyebrow{color:#157c83}a{color:#142c3c!important}table,figure,.card{break-inside:avoid}.md-typeset img{max-height:90vh;object-fit:contain}}
''')

# Draw a code-authored technical figure; keep the SVG as the editable source.
boxes=[(40,105,240,125,'MOTOR SHAFTS','2 DC motors, <=12 V','Disks + A/B sensor mounts'),(330,105,260,125,'OPTICAL SENSING','4 x TCST2103','E1A / E1B / E2A / E2B'),(640,105,260,125,'ANALOG FRONT END','4.7k / 1nF RC + MCP6004','Nominal gain 1.5'),(950,105,240,125,'EDGE CONDITIONING','SN74HC14','4 Schmitt inverter gates'),(640,330,260,140,'PIC18F57Q43 NANO','RB0 / RB1 / RB2 / RB3','Quadrature counts + timing'),(330,330,260,140,'PROPOSED TEAM LINK','RC6 TX / RC7 RX','Connor: main board / PC'),(40,330,240,140,'SYSTEM CONTROL','Main + motor driver','Walker: motor actuation'),(950,330,240,140,'LOCAL POWER','9-12 V -> fuse -> L7805','Regulated +5 V / common GND')]
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1230" height="600" viewBox="0 0 1230 600"><rect width="1230" height="600" rx="18" fill="#f0f5f5"/><defs><marker id="a" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto"><path d="M0,0 L10,4 L0,8 Z" fill="#147b80"/></marker></defs><g font-family="Segoe UI,Arial,sans-serif">']
svg+=['<text x="40" y="45" fill="#142c3c" font-size="25" font-weight="700">Two-motor encoder subsystem</text><text x="40" y="76" fill="#526b75" font-size="17">Elijah Koiki / Team 103 / Revision B alignment / 28 Oct 2026</text>']
im=Image.new('RGB',(2460,1200),'#f0f5f5');dr=ImageDraw.Draw(im)
font='C:/Windows/Fonts/segoeui.ttf'; bold='C:/Windows/Fonts/segoeuib.ttf'
def text(x,y,s,size=17,color='#526b75',weight=False):dr.text((x*2,y*2),s,font=ImageFont.truetype(bold if weight else font,size*2),fill=color)
text(40,20,'Two-motor encoder subsystem',25,'#142c3c',True);text(40,54,'Elijah Koiki / Team 103 / Revision B alignment / 28 Oct 2026')
for x,y,w,h,a,b,c in boxes:
 svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="white" stroke="#bbced1"/><text x="{x+16}" y="{y+30}" font-size="16" fill="#147b80" font-weight="700">{a}</text><text x="{x+16}" y="{y+64}" font-size="17" fill="#142c3c">{b.replace("<","&lt;")}</text><text x="{x+16}" y="{y+94}" font-size="14" fill="#526b75">{c}</text>')
 dr.rounded_rectangle((x*2,y*2,(x+w)*2,(y+h)*2),radius=20,fill='white',outline='#bbced1',width=2)
 text(x+16,y+10,a,16,'#147b80',True);text(x+16,y+45,b,17,'#142c3c');text(x+16,y+78,c,14)
paths=[[(280,165),(330,165)],[(590,165),(640,165)],[(900,165),(950,165)],[(1070,230),(1070,278),(770,278),(770,330)],[(640,400),(590,400)],[(330,400),(280,400)]]
for pts in paths:
 svg.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+'" fill="none" stroke="#147b80" stroke-width="3" marker-end="url(#a)"/>')
 dr.line([(x*2,y*2) for x,y in pts],fill='#147b80',width=6)
 x,y=pts[-1];px,py=pts[-2];ang=math.atan2(y-py,x-px);dr.polygon([(x*2,y*2),((x-12*math.cos(ang-.5))*2,(y-12*math.sin(ang-.5))*2),((x-12*math.cos(ang+.5))*2,(y-12*math.sin(ang+.5))*2)],fill='#147b80')
notes=['+5 V powers sensor emitters, amplifier, Schmitt logic and Nano; motor drive power stays on the driver board.','A/B sensors are offset by 90 electrical degrees per motor. Mounting and ribbon allocation remain pending.','Signal chain shown four times in the schematic. UART is a proposed point-to-point interface, not a shared multi-driver bus.']
for i,n in enumerate(notes):
 svg.append(f'<text x="40" y="{515+i*28}" font-size="16" fill="#526b75">{n}</text>');text(40,495+i*28,n,16)
svg.append('</g></svg>');write('docs/01-Block-Diagram/encoder-block-diagram.svg',''.join(svg));im.save(docs/'01-Block-Diagram/encoder-block-diagram.png')
with zipfile.ZipFile(docs/'01-Block-Diagram/encoder-block-diagram-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['encoder-block-diagram.svg','encoder-block-diagram.png']:z.write(docs/'01-Block-Diagram'/n,n)

for name in ['Team103_Encoder_EK.png','Team103_Encoder_EK.pdf','Team103_Encoder_EK_Project.zip','erc_after.json']:
 copy(source/name,'04-Schematic/'+name)
# Publish portable engineering notes, not local machine paths from raw netlists.
notes=(source/'REVIEW_AND_TESTS.txt').read_text(encoding='utf-8')
notes=notes.replace('R19=10k and C11=1uF give nominal 10 ms recharge','Revision B actually specifies R19=10k and C11=100nF, giving nominal 1 ms recharge; the older 10 ms note is inconsistent')
write('docs/04-Schematic/REVIEW_AND_TESTS.txt',notes)

page('index.md','Motor Encoder Subsystem','''
<div class="hero" markdown>
<div class="eyebrow">RAS304 · Fall 2026 · Team 103</div>

# Giving ordinary motors a sense of position.

Elijah Koiki's motor encoder subsystem for the **2 DOF Smart Robot Arm Joint Showcase**. Four optical channels turn the motion of two DC motor shafts into position and direction feedback for a distributed embedded control system.

<a class="button" href="04-Schematic/schematic/">Explore the schematic →</a>
<a class="button secondary" href="01-Block-Diagram/Block-Diagram/">Follow the signal path</a>
</div>

<div class="meta"><span>Elijah Koiki</span><span>Team 103</span><span>Arizona State University</span><span>Updated October 28, 2026</span></div>

## Project summary

Team 103 is developing a modular, computer-connected control system for a two-degree-of-freedom robotic arm. Custom PCBs add sensing, communication and motor control to basic DC motors rated no higher than 12 V. My board measures both shafts using optical quadrature encoders, conditions their signals, and uses a PIC18F57Q43 Curiosity Nano to prepare feedback for the main controller. This feedback is intended to support the team's closed-loop motion control and telemetry. See the [Team 103 report](https://ras304-f26-103.github.io/) for the wider system.

<div class="stat-grid"><div class="stat"><b>2</b><span>Motor shafts monitored</span></div><div class="stat"><b>4</b><span>Optical A/B channels</span></div><div class="stat"><b>5 V</b><span>Local logic supply</span></div><div class="stat"><b>Rev B</b><span>ERC-reviewed schematic</span></div></div>

## My contribution

I am responsible for the **motor encoder subsystem**: shaft sensing, analog filtering and amplification, digital edge conditioning, local power regulation, and the encoder PIC's connection to the main board. Connor's main board receives the proposed feedback link; Walker's motor driver board controls motor power. Encoder firmware and physical integration are the next implementation steps.

![Updated two-motor encoder block diagram](01-Block-Diagram/encoder-block-diagram.png)

## Explore the design

<div class="cards" markdown>
<div class="card" markdown><div class="number">01 / ARCHITECTURE</div>
### [Block diagram](01-Block-Diagram/Block-Diagram.md)
Trace motion through optical sensing, conditioning, the PIC and the proposed team connection.
</div>
<div class="card" markdown><div class="number">02 / DESIGN CHOICES</div>
### [Component selection](02-Component-Selection/Component-Selection.md)
Compare sensing and circuit options, then review the PIC pin and peripheral plan.
</div>
<div class="card" markdown><div class="number">03 / MATERIALS</div>
### [Bill of materials](03-BOM/BOM.md)
Review the parts extracted from the actual Revision B schematic, including off-board sensors.
</div>
<div class="card" markdown><div class="number">04 / CIRCUIT DESIGN</div>
### [Schematic](04-Schematic/schematic.md)
Inspect the embedded schematic and download its high-resolution PDF and editable KiCad project.
</div>
<div class="card" markdown><div class="number">05 / POWER</div>
### [Power budget](05-Power-Budget/Power-Budget.md)
Review a transparent planning estimate, the 25% margin, and the regulator's thermal limits.
</div>
<div class="card" markdown><div class="number">06 / DESIGN REVIEW</div>
### [Review & resources](Appendix/index.md)
Find verification evidence, outstanding decisions, primary references and the review walkthrough.
</div>
</div>

<div class="status" markdown>
**Current maturity:** Revision B passed KiCad 10.0.7 ERC with zero reported errors and warnings on October 27. Motor mounting, optical performance, firmware, final ribbon agreement and hardware tests remain open. This site presents the documented design and its limits; fabrication approval is pending.
</div>
''')

page('01-Block-Diagram/Block-Diagram.md','Individual Block Diagram','''
# Individual Block Diagram

The encoder board converts the rotation of two motor shafts into four clean digital signals. This updated diagram includes the **MCP6004 amplification and RC filtering stages** required to keep the architecture consistent with the Revision B schematic.

![Two-motor optical encoder architecture with conditioning, PIC, power and team interfaces](encoder-block-diagram.png)

*Figure 1. Two-motor encoder architecture. The arrows show the feedback path; the local power block supplies the sensing and logic circuits.*

[Editable SVG](encoder-block-diagram.svg){.download} [Diagram source ZIP](encoder-block-diagram-source.zip){.download}

## Signal path and design decisions

| Stage | Function | Design rationale |
| --- | --- | --- |
| Shafts and disks | One patterned disk per motor; two sensors per disk | A/B phase order supplies direction as well as incremental motion. |
| Four TCST2103 sensors | LED and phototransistor channels E1A, E1B, E2A, E2B | Bare optical components expose the analog signal for a custom front end. |
| RC + MCP6004 | 4.7 kΩ pull-up / 1 nF node filtering; nominal non-inverting gain 1.5 | Repeated channels support matched conditioning; gain and bandwidth need bench confirmation. |
| SN74HC14 | Four Schmitt inverter gates | Hysteresis converts slow analog transitions into digital edges. Both A/B channels are inverted, preserving their relative quadrature sequence. |
| PIC18F57Q43 Nano | RB0–RB3 receive A/B signals; proposed interrupt-driven decoding | Counts and timing can provide relative position and speed. |
| Team connection | Proposed RC6 TX / RC7 RX through J6, with TX isolation jumper JP1 | A local serial feedback link reduces the number of signals the main board must process. Final bus allocation is pending. |

The encoder board measures motion; Walker's board supplies motor actuation. Separating these roles allows the team to inspect encoder performance independently of the driver. Connor's main controller is the proposed recipient of the feedback and the connection to the PC.

## Power and interface boundaries

J1 accepts the schematic's **9–12 V center-positive DC input**. F1 and U1 provide a fused input and regulated +5 V for the Nano, sensors and conditioning circuits. The team PRD uses 9 V; 12 V is a schematic allowance that increases heating and requires thermal verification. The ribbon shares ground, not the local regulated power rail.

J2–J5 each use three cable conductors: LED drive, phototransistor collector signal, and common ground. The bare sensor has four physical leads; its LED cathode and transistor emitter share the cable ground. Physical sensor lead markings must be checked against the datasheet.

## Position, speed and mounting

For a disk with **N slots**, a quadrature decoder counting all four edges yields **4N counts per disk revolution**. Per-channel pulse frequency is `N × shaft RPM / 60`; speed can be estimated from count change over a known time interval. Gear ratio must be included if a motor-shaft encoder is used to report joint angle.

Mount each A/B pair 90 electrical degrees apart. The corresponding mechanical offset is `90° / N`, modulo the slot pitch. Shaft diameter, disk radius, slot count, maximum RPM and bracket clearances remain dependent on the selected motors. These incremental encoders also need a defined home/reference procedure after power-up.

## Requirement alignment

| Need | Encoder design response | Verification still required |
| --- | --- | --- |
| Feedback for two-axis motion | Independent E1 and E2 quadrature pairs | Compare known shaft rotations with counts in both directions. |
| Custom embedded sensing board | PIC Nano plus bare sensors and discrete conditioning | Review component/package compliance with the teaching team. |
| Local regulated supply | Fuse, L7805, decoupling and status indication | Measure rail voltage and regulator temperature under load. |
| Team coordination | Proposed serial reporting and common ground | Agree ribbon mapping, protocol, levels and power-off behavior. |

Continue to [component selection](../02-Component-Selection/Component-Selection.md) or inspect the [schematic](../04-Schematic/schematic.md).
''')

page('02-Component-Selection/Component-Selection.md','Component Selection','''
# Component Selection

The current choices follow the revised **two-motor optical encoder subsystem**. These comparison tables explain engineering tradeoffs; choices already drawn in Revision B are distinguished from alternatives and decisions awaiting physical measurements.

!!! note "Selection status"
    Current manufacturer pages are linked for verification. Exact orderable packages, supplier quotations and component photographs for every commercial alternative still need a procurement pass; no unverified prices are presented as quotations. Motor and ribbon decisions are deferred until the team confirms them.

## Optical sensing — individual subsystem

| Candidate | Advantages for this project | Limitations | Decision |
| --- | --- | --- | --- |
| **[Vishay TCST2103](https://www.vishay.com/en/product/81147/)** | Bare transmissive LED/phototransistor; analog collector node accessible to the custom front end | Needs a slotted disk, two sensors per shaft and rigid alignment | **Current selection: four sensors** |
| [Vishay TCST1103 family](https://www.vishay.com/en/product/83764/) | Another bare transmissive option with a documented mechanical package | Mechanical fit and optical response require comparison with the actual disk | Alternative if mounting favors this package |
| Custom reflective optical arrangement | Could read a patterned surface without placing a disk inside a fork | Depends on reflectance, ambient light and sensor standoff; needs new optical characterization | Architecture alternative; specific part unselected |

The TCST2103 keeps the design based on ordinary motors and gives each shaft an A/B pair. The sensor choice is conditional on disk and bracket fit. A built-in encoder motor would simplify mounting but would change the project's selected approach and needs team approval.

## Analog amplification — individual subsystem

| Candidate | Advantages | Limitations | Decision |
| --- | --- | --- | --- |
| **[MCP6004](https://www.microchip.com/en-us/product/MCP6004)** | Four amplifier channels in one IC; rail-to-rail input/output family; 1 MHz class | Current gain drives high inputs into saturation; recovery must be tested | **Current selection: U2, nominal gain 1.5** |
| [MCP6024](https://www.microchip.com/en-us/product/mcp6024) | Quad rail-to-rail family with 10 MHz bandwidth | More bandwidth may increase sensitivity to noise; power/package review needed | Alternative if measured edge response requires it |
| Two dual amplifiers | Splits channels across two packages for placement flexibility | Larger BOM and layout; exact device and supply compatibility unselected | Architecture alternative |

Each channel uses a 10 kΩ feedback resistor and 20 kΩ resistor to ground: `1 + 10k/20k = 1.5`. The 4.7 kΩ / 1 nF network has a nominal pole near **33.9 kHz** and a time constant of **4.7 µs**. Phototransistor impedance changes the actual response. Optical contrast, amplifier rail behavior and pulse timing require measurement before these values can be accepted.

## Digital edge conditioning — individual subsystem

| Candidate | Advantages | Limitations | Decision |
| --- | --- | --- | --- |
| **[SN74HC14](https://www.ti.com/product/SN74HC14)** | Six Schmitt inverter gates; four are sufficient for the encoder signals | Thresholds and dynamic supply current must be checked at operating voltage and edge rate | **Current selection: SN74HC14N / U3** |
| [CD40106B](https://www.ti.com/product/CD40106B) | Six Schmitt inverter gates; broad supply range | Timing and thresholds differ; cannot substitute without checking the pulse rate | Alternative |
| PIC input conditioning only | Fewer external components | Relies on PIC input behavior and software; removes the explicit external Schmitt stage | Architecture alternative requiring redesign |

The four used HC14 gates provide consistent edge conditioning. Unused inputs are tied to a defined level in the schematic. Both channels of each quadrature pair are inverted, so firmware must establish the actual forward direction during calibration.

## Regulation and power source

| Regulator option | Advantages | Limitations | Decision |
| --- | --- | --- | --- |
| **[ST L78 / L7805ACV](https://www.st.com/en/power-management/l78.html)** | Simple local 5 V rail; familiar through-hole package; matches Revision B | Linear dissipation rises with input voltage; heatsink and load must be verified | **Current schematic selection** |
| [ST L4940V5](https://www.st.com/en/power-management/l4940.html) | Lower dropout can help when input headroom is limited | At the same input/output/current, linear heat remains similar; stability and pinout need review | Alternative, not a drop-in approval |

The team PRD specifies an individual **9 V wall adapter**; Revision B labels its jack 9–12 V. A current-limited bench supply is suitable for development. A final adapter model, plug dimensions, current rating and procurement price have not been selected. A battery option adds runtime, charging and discharge considerations without a current project need. The [power budget](../05-Power-Budget/Power-Budget.md) explains why 9 V is thermally preferable to 12 V for the same load.

## PIC pins and MCC configuration plan

This is the configuration to implement and verify in MCC, derived from the schematic's Nano connector labels. **No completed MCC project or screenshot is available in the reviewed files.** Edge numbers below refer to the Nano board, not the MCU package pins.

| Signal | PIC pin | Nano edge | Planned configuration |
| --- | --- | --- | --- |
| E1A_DIG | RB0 | 46 | Digital input; interrupt-on-change candidate |
| E1B_DIG | RB1 | 10 | Digital input; interrupt-on-change candidate |
| E2A_DIG | RB2 | 9 | Digital input; interrupt-on-change candidate |
| E2B_DIG | RB3 | 47 | Digital input; interrupt-on-change candidate |
| MCU_TX → JP1 → ENC_TX | RC6 | 13 | UART TX via peripheral pin select; final UART instance and baud pending |
| ENC_RX | RC7 | 19 | UART RX via peripheral pin select; team protocol pending |
| DEBUG_LED | RA3 | 16 | Digital output; choose initial low state |
| DEBUG_BTN | RA4 | 17 | Digital input; stable-state firmware debounce |
| Spare GPIO | RA0 / RA1 | 43 / 44 | Reserved; do not assign conflicting peripherals |
| External +5 V | VTG | 51 | Verify Nano external-power procedure; VOFF edge 55 tied to ground |

Disable analog functions on digital signals, configure the selected clock and timing source, initialize quadrature state before enabling interrupts, and verify the worst-case interrupt rate. A periodic timer and an atomic count snapshot can support speed reporting. UART framing, signed count width, update period and fault handling remain firmware design decisions.

## What remains to finalize

Confirm motor and disk geometry; complete commercial comparisons with exact prices and photos; finalize the power adapter and package/footprint choices; capture the actual MCC pin/peripheral configuration; and obtain teaching-team feedback on the amplifier/filter design. The [BOM](../03-BOM/BOM.md) lists the components currently drawn.
''')

# Generate grouped BOM from actual netlist, including explicitly off-board sensors.
sys.path.insert(0,str(source));from parseutil import parse,ch,children
root=parse((source/'after.net').read_text());groups=defaultdict(list)
for c in children(ch(root,'components'),'comp'):groups[ch(c,'value')[1]].append(ch(c,'ref')[1])
rows=[]
for value,refs in groups.items():rows.append([', '.join(refs),len(refs),value,'Package / sourcing pending' if not value in ['MCP6004','SN74HC14N'] else 'DIP-14 assigned; verify exact orderable suffix'])
rows.append(['Q1–Q4',4,'Vishay TCST2103 (off-board)','Physical lead mapping and mounting pending'])
p=docs/'03-BOM/encoder-revb-bom.csv';p.parent.mkdir(parents=True,exist_ok=True)
with p.open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['References','Quantity','Description / value','Procurement status']);w.writerows(rows)
table='\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)
page('03-BOM/BOM.md','Bill of Materials','''
# Bill of Materials

This design BOM is extracted from the **Revision B exported KiCad netlist**. Q1–Q4 are added explicitly because the off-board optical sensors are intentionally excluded from the PCB netlist. IC units count as one physical package each.

[Download BOM CSV](encoder-revb-bom.csv){.download} [Download KiCad project](../04-Schematic/Team103_Encoder_EK_Project.zip){.download}

| References | Quantity | Description / value | Procurement status |
| --- | ---: | --- | --- |
'''+table+'''

## Procurement and assembly notes

Prices and a procurement total are **unavailable until the exact package and supplier choices are confirmed**. The current schematic has several unassigned footprints; the Nano socket, jack, fuse holder, connectors and passive packages need a physical fit check. Use the [component selection references](../02-Component-Selection/Component-Selection.md) to verify manufacturer specifications before ordering.

The 500 mA removable fast fuse is the drawn value, not a completed protection study. Verify its time-current curve, holder rating and wire/trace protection against the actual load. Optical sensors, disks, mounting brackets, cables, an adapter, sockets and any heatsink must be included in the final purchasing list.

**Consistency note:** C11 is **100 nF** in the actual Revision B netlist. With R19 = 10 kΩ, its nominal RC time constant is **1 ms**. An older schematic note says 10 ms; review and correct that annotation or intentionally revise the component value before fabrication.
''')

page('04-Schematic/schematic.md','Schematic Design','''
# Schematic Design

Revision B implements four optical channels for two motors, local 5 V regulation, a PIC18F57Q43 Nano, debug I/O and the proposed serial interface to the main board. The full schematic is embedded below; select the image to zoom, or open the PDF to inspect small labels.

![Revision B two-motor optical encoder schematic, Elijah Koiki, Team 103](Team103_Encoder_EK.png)

*Figure 2. Revision B, reviewed October 27, 2026 in KiCad 10.0.7.*

[High-resolution schematic PDF](Team103_Encoder_EK.pdf){.download} [Complete KiCad project ZIP](Team103_Encoder_EK_Project.zip){.download} [ERC report JSON](erc_after.json){.download} [Engineering review notes](REVIEW_AND_TESTS.txt){.download}

## How the circuit works

### 1. Protected local power

J1 takes a center-positive 9–12 V source. F1 feeds VIN_FUSED, and the L7805ACV generates +5 V. Input/output capacitors and local decoupling support the regulator and ICs; the green power LED indicates that the rail is present. Test points expose VIN_FUSED, +5 V and ground. Regulator thermal performance must be verified using the [power budget](../05-Power-Budget/Power-Budget.md).

The Nano is represented as a passive connector: +5 V enters VTG edge 51 and VOFF edge 55 is grounded, following the external-power approach documented in the Nano user guide. VBUS edge 56 is not connected in this design. Check board orientation and the guide before connecting external power and USB.

### 2. Optical current to analog voltage

Four off-board TCST2103 sensors monitor the two disks. Each emitter uses a 220 Ω series resistor, giving approximately `(5 − 1.25) / 220 = 17 mA` under the stated nominal forward-drop assumption. The phototransistor collector works with a 4.7 kΩ pull-up and a 1 nF capacitor. TP4–TP7 expose the raw channels for blocked/unblocked testing.

### 3. Amplification and digital edges

U2 is a quad MCP6004. Each non-inverting stage has nominal gain 1.5; a high raw signal can drive its output into positive saturation. That behavior makes saturation recovery, rail levels and pulse width key bench tests. The SN74HC14 then applies Schmitt hysteresis and inversion before RB0–RB3 receive the signals. The filter's nominal 33.9 kHz pole is a calculation, not a demonstrated operating-rate limit.

### 4. Counting and reporting

The PIC's proposed firmware tracks transitions in each A/B pair and reports counts and timing to the main board. RC6 TX passes through JP1 to J6; removing JP1 isolates the transmit path. RC7 receives ENC_RX. The proposed connection is **5 V logic UART**, not RS-232 voltage levels. Shared multidriver operation has not been approved; the team must resolve addressing/topology and avoid output contention.

### 5. Debug and serviceability

RA3 drives the yellow debug LED. RA4 reads SW1 with R19 and C11; firmware debounce remains necessary. RA0/RA1 are available at J7. Labeled connectors, channel test points and the TX jumper support independent bring-up of the power, sensing and communication stages.

## Verification evidence

| Check | Recorded result | Scope |
| --- | --- | --- |
| Original schematic ERC | 2 errors, 125 warnings | Baseline from the local review records |
| Revision B CLI and GUI ERC | **0 errors, 0 warnings** | KiCad 10.0.7, October 27, 2026 |
| Netlist comparison | Connected PCB component pin sets unchanged | Original and Revision B electrical connectivity comparison |
| Hardware sensing, firmware and physical fit | **Pending** | No working prototype or measurement record supplied |
| Encoder PCB layout / DRC | **Pending** | The encoder project contains a schematic, not a validated PCB layout |

The ERC report retains four default ignored categories: single global label, four-way junction, simulation model issue and footprint filter. No individual violations were excluded to obtain the reported pass. ERC checks schematic rules; it does not validate the optical or analog performance, Nano firmware directions, footprint fit or safe operating temperature.

## Open items before fabrication

Confirm optical mounting and the maximum pulse rate; measure amplifier recovery and clean HC14 output levels; resolve the **C11 100 nF / 1 ms versus 10 ms annotation mismatch**; select and verify missing footprints; check external power and thermal behavior; and agree the final ribbon mapping with the team. The detailed [review checklist](../Appendix/index.md) provides the bring-up sequence.
''')

power_rows=[('Nano board + MCU',1,100,'Planning allowance; actual firmware/debugger load unmeasured'),('TCST2103 emitters',4,(5-1.25)/220*1000,'Calculated nominal, 220 ohm / 1.25 V assumed LED drop'),('Collector pull-ups',4,5/4700*1000,'All four raw nodes low; conservative pull-up bound'),('MCP6004 + feedback',1,2,'Planning allowance including output/feedback loading'),('SN74HC14',1,5,'Planning allowance; depends on input edges and frequency'),('Power + debug LEDs',2,3,'Planning allowance, 1k series resistors'),('Debug pull-up',1,0.5,'Button held low, 10k at 5 V')]
total=sum(q*i for _,q,i,_ in power_rows);margin=total*1.25
write('docs/05-Power-Budget/budget-inputs.json',json.dumps({'status':'preliminary planning estimate; not datasheet maximum or measured certification','rail_voltage':5,'margin':.25,'rows':[{'name':n,'quantity':q,'unit_ma':i,'basis':b} for n,q,i,b in power_rows],'total_ma':total,'with_margin_ma':margin},indent=2))
pt='\n'.join(f'| {n} | {q} | {i:.2f} | {q*i:.2f} | {b} |' for n,q,i,b in power_rows)
page('05-Power-Budget/Power-Budget.md','Power Budget','''
# Power Budget

This **preliminary encoder-board planning estimate** accounts for the four emitters, PIC board, analog/logic ICs and support loads, then adds the required **25% margin**. Motors are powered on the motor-driver subsystem and are excluded from this local rail.

!!! warning "Estimate, not a verified maximum-current budget"
    The Nano, amplifier and logic entries include explicitly labeled planning allowances. They are not measured results or datasheet absolute maxima. A final course-template budget requires verified worst-case operating currents, the exact adapter and thermal measurements. Absolute maximum ratings are stress limits and should not be used as intended operating points.

## A · Loads on the +5 V rail

| Load | Quantity | Unit current (mA) | Total (mA) | Basis |
| --- | ---: | ---: | ---: | --- |
'''+pt+f'''

## B · Rail demand and margin

| Result | Planning estimate |
| --- | ---: |
| Sum of local +5 V loads | **{total:.2f} mA** |
| Safety margin | **25%** |
| +5 V design-current estimate with margin | **{margin:.2f} mA** |
| Output power at the margin load | **{5*margin/1000:.3f} W** |

The emitters alone account for about 68 mA under the nominal forward-drop assumption. Measure blocked/unblocked sensor currents and the running Nano board to replace the allowances. Current uncertainty and regulator heating matter more than the regulator's headline current rating.

## C · Regulator and thermal check

The schematic uses **L7805ACV**. Ignoring regulator ground current, `P_loss = (V_in − 5 V) × I_out`.

| Input | Dissipation at {margin:.2f} mA | Ideal linear conversion efficiency |
| --- | ---: | ---: |
| 9 V | **{4*margin/1000:.3f} W** | 55.6% |
| 12 V | **{7*margin/1000:.3f} W** | 41.7% |

Regulator ground current adds input demand and dissipation. A heatsink/thermal design cannot be accepted from these numbers alone: check the actual package's junction-to-ambient or heatsink path, ambient temperature, maximum junction temperature and mounting. At the earlier review example of 250 mA, 12 V input produces approximately **1.75 W** before ground-current loss.

## D · External source

The team PRD specifies a **9 V wall adapter**, while the schematic allows 9–12 V at J1. A particular adapter is still unselected. Its usable continuous current must exceed the margin load plus regulator ground current, with appropriate polarity and connector fit. Until its rated output and regulator current are verified, remaining source capacity is **unavailable**. Start bring-up with a current-limited bench supply.

The drawn 500 mA fuse does not establish a safe supply rating or guaranteed semiconductor protection. Check the time-current characteristic, inrush, wiring and regulator thermal limits before accepting it.

## E · Battery runtime

**Not applicable to the current wall-powered concept.** If a battery is selected later, add usable capacity, discharge limits, conversion loss and runtime at the verified load.

## Reusable calculation

[Editable power-budget workbook](Team103_Encoder_Power_Budget.xlsx){{.download}} [Machine-readable inputs](budget-inputs.json){{.download}}

The workbook follows sections A–E and exposes the assumptions. It is a working planning model; final supplier and measurement data must replace the marked allowances before claiming a completed worst-case course budget.
''')

# Keep the prior sensor assignment available without confusing it with the new encoder design.
copy(Path('C:/Users/elija/Downloads/EK_Sensor103_Project.zip'),'Appendix/EK_Sensor103_Project.zip')
with zipfile.ZipFile(docs/'Appendix/EK_Sensor103_Project.zip') as z:
 for n in ['EK103_JLCDFM_Results.pdf','JLCDFM_Results.jpg','EK103_Schematic_PCB.pdf']:
  target='EK_Sensor103/'+n
  if target in z.namelist():(docs/'Appendix'/n).write_bytes(z.read(target))
page('Appendix/index.md','Review & Resources','''
# Review & Resources

## External review walkthrough

For the October 29, 2026 design review, use the [overview](../index.md) to introduce the subsystem, the [block diagram](../01-Block-Diagram/Block-Diagram.md) and [component selection](../02-Component-Selection/Component-Selection.md) to explain the architecture, then the [schematic](../04-Schematic/schematic.md) to follow one channel and its power/debug circuits. The [power budget](../05-Power-Budget/Power-Budget.md) supports the thermal discussion.

## Readiness and next decisions

| Item | Status | Next action |
| --- | --- | --- |
| Individual page content and navigable assignment sections | Updated for the encoder subsystem | Keep content synchronized as design decisions change. |
| Block diagram | Updated to include amplification/filtering | Review after final mechanical and interface decisions. |
| Schematic downloads and visible raster image | Revision B provided | Correct C11 annotation mismatch before fabrication. |
| Schematic ERC evidence | Recorded pass | Re-run after any electrical change. |
| Component comparisons | Current selections and tradeoffs documented | Complete commercial alternatives, exact unit costs and photos. |
| Power budget | Preliminary calculation with 25% margin | Verify load currents, adapter rating, regulator ground current and thermal limits. |
| MCC configuration | Pin/peripheral plan documented | Implement and capture the actual MCC configuration. |
| Motors and disks | Pending, intentionally deferred | Confirm shaft dimensions, speed, gearing, slot count and bracket design. |
| Ribbon interface | Proposed only, intentionally deferred | Agree pin mapping and protocol with Connor and the team. |
| Encoder PCB and bench measurements | Pending | Complete layout, physical fit checks and bring-up. |
| Team-site cross-link | Team report linked from this site | Ask the team to link Elijah's individual URL from its landing page. |

The [team PRD](https://ras304-f26-103.github.io/04-Product-Requirements/) still reflects an earlier subsystem allocation and bus mapping. This individual site follows Elijah's revised encoder role and the two-motor decision. A team-level reconciliation remains necessary; this update does not change the team repository.

## Bench verification sequence

1. Inspect connector orientation and continuity with power disconnected. Confirm fuse, regulator pins and the Nano external-power wiring.
2. Power the disconnected logic board from a current-limited supply; measure VIN_FUSED and +5 V, then check full-load temperature with the complete assembly.
3. Block and unblock each optical sensor. Probe TP4–TP7, U2 outputs and HC14 outputs for voltage levels, noise and saturation recovery.
4. Rotate each disk in both directions. Check A/B phase order, known counts per revolution and the highest required edge rate.
5. Implement firmware counting, a home/reference procedure and stable-state button debounce; verify interrupt loading and count snapshot integrity.
6. Agree the final serial link and connect one board at a time. Test TX isolation, framing, stale-data behavior and power-off conditions.

## Previous sensor-design assignment

The earlier **EK_Sensor103** KiCad/PCB exercise is retained here as a separate assignment artifact. Its DFM result does not certify the current two-motor encoder schematic or an encoder PCB.

![Recorded JLCDFM result from the earlier sensor-design assignment](JLCDFM_Results.jpg)

The prior conversation recorded **0 danger findings and 7 warnings**. The warning locations were not fully confirmed; an assumption that they came from EK copper lettering remains unverified.

[Sensor assignment project ZIP](EK_Sensor103_Project.zip){.download} [Recorded DFM PDF](EK103_JLCDFM_Results.pdf){.download} [Sensor schematic / PCB PDF](EK103_Schematic_PCB.pdf){.download}

## Primary references

- [Microchip PIC18F57Q43 Curiosity Nano hardware user guide](https://ww1.microchip.com/downloads/aemDocuments/documents/MCU08/ProductDocuments/UserGuides/PIC18F57Q43-Curiosity-Nano-HW-UserGuide-DS40002186B.pdf) — board pinout and external power.
- [Vishay TCST2103 family datasheet](https://www.vishay.com/docs/81147/tcst2103.pdf) — sensor package, optical/electrical characteristics and lead markings.
- [Microchip MCP6004](https://www.microchip.com/en-us/product/MCP6004) — quad amplifier documentation.
- [Texas Instruments SN74HC14](https://www.ti.com/product/SN74HC14) — Schmitt inverter electrical specifications.
- [ST L78 family](https://www.st.com/en/power-management/l78.html) — regulator pinout, operating limits and thermal specifications.
- [Team 103 report](https://ras304-f26-103.github.io/) — shared project context; older role/interface assignments need team reconciliation.

## Design record

October 27: local KiCad review rebuilt the schematic grid, corrected ERC findings and exported Revision B. October 28: individual datasheet replaced the template examples, embedded the reviewed circuit, updated the block diagram to include conditioning, documented component rationale and added a preliminary power model. Source symbol geometry includes custom and adapted library work; EK labels alone do not establish personal authorship.
''')

write('README.md','''
# Elijah Koiki — RAS304 Team 103

Individual datasheet for the two-motor encoder subsystem.

Live site: https://kek-koiki.github.io/kkoiki_RAS304_F26/

## Local development

```powershell
python -m pip install -r requirements.txt
python -m mkdocs serve
```

Run `python -m mkdocs build --strict` before publishing. Markdown lives in `docs/`; existing assignment URLs are retained. Push to `main` to trigger the GitHub Pages workflow. Build output in `site/` is ignored for future changes (legacy tracked output is retained).

The schematic's ERC pass is recorded evidence, not hardware validation. Open technical decisions and missing final inputs are listed on the Review & Resources page. No motor/ribbon approval, firmware implementation or fabrication readiness is claimed.
''')
print('Website content prepared at',repo)
print('Power estimate:',total,'mA; with margin:',margin,'mA')
