"""Exercise an example teacher edit without modifying repository data or outputs."""
from pathlib import Path
import runpy,json,copy
root=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26')
module=runpy.run_path(str(root/'tools/bom/render.py'))
outputs=module['outputs'];scope=outputs.__globals__;original_load=scope['load']
def edited_load(name):
    value=copy.deepcopy(original_load(name))
    if name=='core.json':
        sensor=next(p for p in value if p['key']=='tcst2103')
        sensor['qty']=5;sensor['price']=2.00
    return value
scope['load']=edited_load
result=outputs();record=json.loads(result['docs/03-BOM/encoder-parts-sources.json'])
assert record['subtotal']=='41.59'
assert next(p for p in record['parts'] if p['key']=='tcst2103')['line_total']==10
assert '5 pieces' in result['docs/02-Component-Selection/Component-Selection.md']
assert '**$10.00**' in result['docs/03-BOM/BOM.md']
print('Example quantity/price edit updates cards, BOM, export and subtotal correctly; no files written.')
