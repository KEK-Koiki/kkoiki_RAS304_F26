from pathlib import Path
import urllib.request,json,re
from html.parser import HTMLParser
class Meta(HTMLParser):
 def __init__(self):super().__init__();self.meta={}
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='meta':self.meta[a.get('property',a.get('name',''))]=a.get('content','')
u='https://www.digikey.com/en/products/detail/texas-instruments/SN74HC14N/277223'
h=urllib.request.urlopen(u).read().decode();m=Meta();m.feed(h)
print(len(h),{k:v for k,v in m.meta.items() if 'image' in k or 'price' in k})
print(re.findall(r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>',h)[:1])
Path('supplier-sample.html').write_text(h,encoding='utf-8')
