import sharp from 'sharp';
import fs from 'node:fs/promises';
const dir='C:/Users/elija/Website Repos/kkoiki_RAS304_F26/docs/01-Block-Diagram/';
await sharp(await fs.readFile(dir+'encoder-detailed-block-diagram.svg'),{density:150}).png().toFile(dir+'encoder-detailed-block-diagram.png');
console.log('Detailed diagram rendered');
