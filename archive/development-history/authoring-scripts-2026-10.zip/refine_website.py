from pathlib import Path
import json,urllib.request,csv,zipfile,html,sys
from decimal import Decimal
from PIL import Image

base=Path(__file__).resolve().parent
repo=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26')
docs=repo/'docs'
catalog=json.loads((base/'parts-catalog.json').read_text())
assets=docs/'static/parts';assets.mkdir(parents=True,exist_ok=True)
for key,p in catalog.items():
 if p.get('image'):
  target=assets/(key+'.jpg')
  if not target.exists():
   try:
    target.write_bytes(urllib.request.urlopen(p['image'],timeout=25).read())
    with Image.open(target) as im:im.verify()
   except Exception as e:
    print('Image download failed',key,str(e));continue
  p['local_image']='../static/parts/'+key+'.jpg'

def write(path,text):
 p=docs/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def part(key,refs,qty,mfr,mpn,desc,note='',group='Core electronics'):
 p=dict(catalog[key]);p.update(key=key,refs=refs,qty=qty,manufacturer=mfr,mpn=mpn,description=desc,note=note,group=group)
 return p
parts=[
 part('nano','A1',1,'Microchip','DM164150','PIC18F57Q43 Curiosity Nano','Board already specified; include replacement cost even if course-provided.'),
 part('tcst2103','Q1–Q4',4,'Vishay','TCST2103','Bare optical interrupter, 3.1 mm slot','Off-board A/B sensors; fit to the disk and bracket still required.'),
 part('mcp6004','U2',1,'Microchip','MCP6004-I/P','Quad rail-to-rail op-amp, PDIP-14','Orderable through-hole example for the MCP6004 drawn in Revision B.'),
 part('hc14','U3',1,'Texas Instruments','SN74HC14N','Hex Schmitt inverter, PDIP-14','Four gates used; two unused inputs held at a defined level.'),
 part('l7805','U1',1,'STMicroelectronics','L7805ACV','5 V linear regulator, TO-220','Thermal design and heatsink remain to be verified.'),
 part('r220','R2, R6, R10, R14',4,'YAGEO','CFR-25JB-52-220R','220 Ω, 0.25 W, ±5% axial resistor',group='Passives'),
 part('resistor','R1, R18',2,'YAGEO','CFR-25JB-52-1K','1 kΩ, 0.25 W, ±5% axial resistor',group='Passives'),
 part('r4k7','R3, R7, R11, R15',4,'YAGEO','CFR-25JB-52-4K7','4.7 kΩ, 0.25 W, ±5% axial resistor',group='Passives'),
 part('r10k','R4, R8, R12, R16, R19',5,'YAGEO','CFR-25JB-52-10K','10 kΩ, 0.25 W, ±5% axial resistor',group='Passives'),
 part('r20k','R5, R9, R13, R17',4,'YAGEO','CFR-25JB-52-20K','20 kΩ, 0.25 W, ±5% axial resistor','DigiKey page lists backorder; compare Mouser availability before ordering.',group='Passives'),
 part('cap330nf','C1',1,'KEMET','C330C334M5U5TA','0.33 µF, 50 V, Z5U radial capacitor','50 V example exceeds the schematic’s 25 V rating; check 5.08 mm lead spacing.',group='Passives'),
 part('cap100nf','C2, C8, C9, C10, C11',5,'KEMET','C315C104M5U5TA','0.1 µF / 100 nF, 50 V, Z5U radial capacitor','Example value/rating match; X7R may be preferable where stability matters.',group='Passives'),
 part('cap1nf','C4–C7',4,'KEMET','C315C102J5G5TA','1 nF, 50 V, ±5% C0G radial capacitor','C0G dielectric supports a more stable filter capacitance.',group='Passives'),
 part('cap10uf','C3',1,'Panasonic','EEA-FC1E100','10 µF, 25 V, radial aluminum capacitor','Polarized example: verify + terminal and footprint lead spacing.',group='Passives'),
 part('jack','J1',1,'Same Sky','PJ-102A','Right-angle through-hole DC barrel jack','Example only: confirm plug fit, polarity and physical pad numbering.',group='Connectors, protection & debug'),
 part('fuse','F1 fuse',1,'Littelfuse','0217.500MXP','500 mA fast-acting 5 × 20 mm cartridge fuse','Separate removable fuse and holder; validate protection and DC application.',group='Connectors, protection & debug'),
 part('holder','F1 holder',1,'SCHURTER','0031.8201','PCB fuse holder for 5 × 20 mm cartridge','Physical holder example; footprint must match its drawing.',group='Connectors, protection & debug'),
 part('header3','J2–J5',4,'Sullins','PRPC003SAAN-RC','1 × 3 male header, 2.54 mm','Board-side sensor headers only; mating housings/cables excluded.',group='Connectors, protection & debug'),
 part('header8','J6',1,'3M','N2508-6002-RB','2 × 4 shrouded male header, 2.54 mm','Example sold individually; final ribbon connector and pinout require team agreement.',group='Connectors, protection & debug'),
 part('header4','J7',1,'Sullins','PRPC004SAAN-RC','1 × 4 male header, 2.54 mm','Spare GPIO / +5 V / GND.',group='Connectors, protection & debug'),
 part('header2','JP1 header',1,'Sullins','PRPC002SAAN-RC','1 × 2 male header, 2.54 mm',group='Connectors, protection & debug'),
 part('shunt','JP1 shunt',1,'Sullins','NPC02SXON-RC','2.54 mm removable jumper shunt','Separate shunt needed to close TX isolation jumper.',group='Connectors, protection & debug'),
 part('green','D1',1,'Kingbright','WP7113GD','5 mm green through-hole LED',group='Connectors, protection & debug'),
 part('yellow','D2',1,'Kingbright','WP7113YD','5 mm yellow through-hole LED',group='Connectors, protection & debug'),
 part('switch','SW1',1,'Omron','B3F-1000','Through-hole momentary SPST-NO tactile switch','Four physical legs, two electrical contacts; verify paired pins in the footprint.',group='Connectors, protection & debug'),
 part('testpoint','TP1–TP9',9,'Keystone','5010','Through-hole loop test point','One red example for pricing; distinguish GND by marking or a black variant.',group='Connectors, protection & debug')
]
# All unpriced items are kept separate from the sourced subtotal.
for p in parts:
 if p.get('price') is None:raise ValueError('Missing verified price: '+p['key'])
 p['line_total']=float(Decimal(str(p['price']))*p['qty'])
 if not p.get('local_image') and p['key'] in ['r220','r4k7','r10k','r20k']:p['local_image']=catalog['resistor'].get('local_image')
subtotal=sum(Decimal(str(p['line_total'])) for p in parts)
core=sum(Decimal(str(p['line_total'])) for p in parts if p['group']=='Core electronics')
passive=sum(Decimal(str(p['line_total'])) for p in parts if p['group']=='Passives')
interface=subtotal-core-passive

def photo(p,width=78):
 return f'<img src="{p["local_image"]}" alt="{html.escape(p["mpn"])} supplier reference photo" width="{width}" loading="lazy">' if p.get('local_image') else ''
def table(rows):
 t=['<div class="bom-table" markdown>','', '| Part / reference photo | Ref. / Qty | Manufacturer & example MPN | Unit USD | Line USD | Sources |','| --- | --- | --- | ---: | ---: | --- |']
 for p in rows:
  im=photo(p);ds=p.get('datasheet')
  links=f'[Supplier]({p["source"]})'+(f' · [Datasheet]({ds})' if ds else ' · specs/docs on supplier page')
  t.append(f'| {im}<br>**{p["description"]}** | {p["refs"]}<br>**{p["qty"]} pcs** | {p["manufacturer"]}<br><code>{p["mpn"]}</code> | ${p["price"]:.2f} | **${p["line_total"]:.2f}** | {links} |')
 t.extend(['','</div>']);return '\n'.join(t)

bom='''---
title: Bill of Materials
---

# Bill of Materials

The purchasing examples below translate the **Revision B encoder schematic** into a priced parts list for one two-motor encoder subsystem. They include four off-board optical sensors, and count each multi-unit IC as one physical package. Fuse/holder and jumper/shunt are listed separately so those small but necessary pieces are not missed.

<div class="meta"><span>1 encoder subsystem</span><span>USD · quantity-one reference prices</span><span>Sources reviewed October 28, 2026</span></div>

## Cost at a glance

'''+f'''<div class="stat-grid"><div class="stat"><b>${subtotal:.2f}</b><span>Sourced parts subtotal</span></div><div class="stat"><b>${core:.2f}</b><span>Controller + sensors + ICs</span></div><div class="stat"><b>${passive:.2f}</b><span>Resistors + capacitors</span></div><div class="stat"><b>${interface:.2f}</b><span>Connectors + protection + debug</span></div></div>
'''+'''
Each line uses the supplier page's **one-piece unit price multiplied by the quantity needed**, without assuming volume discounts. These are dated reference prices, not a checkout quotation. Shipping, taxes, tariffs, custom PCBs, assembly, Nano sockets, mating cables, disk/bracket fabrication and thermal hardware are excluded. The optional adapter is listed separately below.

[Download priced BOM CSV](encoder-revb-bom.csv){.download} [Download sourcing record](encoder-parts-sources.json){.download} [Download KiCad project](../04-Schematic/Team103_Encoder_EK_Project.zip){.download}

## Core electronics

'''+table([p for p in parts if p['group']=='Core electronics'])+'''

## Resistors and capacitors

'''+table([p for p in parts if p['group']=='Passives'])+'''

*Resistor photos are representative of the YAGEO CFR axial family; band colors vary with resistance. Supplier capacitor images can also represent a family. The printed MPN, electrical value and dimensional drawing govern selection.*

## Connectors, protection and debug

'''+table([p for p in parts if p['group']=='Connectors, protection & debug'])+'''

## External power example

'''
adapter=part('adapter','External to board',1,'MEAN WELL','GST18A09-P1J','9 V / 2 A desktop adapter','Power-source purchasing candidate, not a change to the schematic.')
adapter['line_total']=adapter['price'];bom+=table([adapter])+f'''

Adding this adapter gives an illustrative **${subtotal+Decimal(str(adapter['price'])):.2f} parts-plus-adapter subtotal**, before the exclusions above. Its AC input cord is sold separately. Check its 5.5 × 2.1 mm center-positive plug against the chosen jack and confirm the mains cord needed locally. This adapter's 2 A rating is available capacity; it does not mean the encoder consumes 2 A or resolves regulator heating.

## Fit, sourcing and assembly notes

'''
for p in parts:
 if p['note']:bom+=f'- **{p["refs"]} / {p["mpn"]}:** {p["note"]}\n'
bom+='''
## Items still requiring a quote or team decision

| Item | Quantity / scope | Why it is outside the priced subtotal |
| --- | --- | --- |
| Nano carrier sockets | Two 1 × 28 receptacles; example Sullins PPPC281LFBN-RC | Confirm stack height, footprint and current small-quantity quote. |
| Sensor cables and mates | Four three-conductor assemblies | Length, strain relief, connector polarization and motor placement remain open. |
| Ribbon cable and IDC mate | Team cable assembly | Final connector orientation, length and signal allocation are deferred. |
| Encoder disks and brackets | Two disks / four sensor mounts | Shaft diameter, slots and clearances depend on the selected motors. |
| Regulator heatsink / hardware | As required by thermal measurements | TO-220 fit, airflow and temperature rise must be checked. |
| Custom encoder PCB and mounting hardware | One board | Layout is not yet complete; obtain fabrication/assembly pricing later. |
| Motors | Two, on the driver subsystem | Team-selected actuation hardware; excluded from this individual encoder BOM. |

## Photo credits and selection status

Reference product images are supplied by the linked manufacturers through DigiKey; attribution and original image URLs are retained in the sourcing record. Images are hosted locally for reliable display. Photographs show purchasing examples, not parts already owned or assembled. New support-component MPNs are **fit-check candidates**; they do not imply assigned or verified PCB footprints.

**Revision B consistency:** C11 is 100 nF in the exported netlist. With R19 = 10 kΩ, the nominal time constant is 1 ms. Resolve the older 10 ms annotation before fabrication. No schematic electrical values were changed during this website refinement.
'''
write('03-BOM/BOM.md',bom)
with (docs/'03-BOM/encoder-revb-bom.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['Group','References','Quantity','Description','Manufacturer','Example MPN','Unit USD (qty 1)','Extended USD','Supplier URL','Selection notes'])
 for p in parts:w.writerow([p['group'],p['refs'],p['qty'],p['description'],p['manufacturer'],p['mpn'],f'{p["price"]:.2f}',f'{p["line_total"]:.2f}',p['source'],p['note']])
write('03-BOM/encoder-parts-sources.json',json.dumps({'reviewed':'2026-10-28','currency':'USD','basis':'One-piece supplier-page reference unit price multiplied by design quantity; not checkout quote','subtotal':str(subtotal),'parts':parts,'optional_adapter':adapter},indent=2,ensure_ascii=False))

# Add photo-and-price cards ahead of the existing rationale, preserving all pin/MCC sections.
component=docs/'02-Component-Selection/Component-Selection.md'
text=component.read_text(encoding='utf-8')
start=text.index('!!! note "Selection status"');end=text.index('## Optical sensing',start)
cards='''## Selected parts at a glance

These are example orderable versions of the components already drawn in Revision B. Prices are **USD per piece at the supplier's quantity-one tier**, reviewed October 28, 2026. The four sensors therefore cost four times the displayed sensor unit price. The [detailed BOM](../03-BOM/BOM.md) includes quantities, line totals, passives, connectors and fit-check notes.

<div class="component-cards" markdown>
'''
for p in parts[:5]:
 cards+=f'''<div class="component-card" markdown>
{photo(p,160)}
<div class="number">{p['refs']} · {p['qty']} {'pieces' if p['qty']>1 else 'piece'}</div>
### {p['mpn']}
{p['description']}

**${p['price']:.2f} each · ${p['line_total']:.2f} extended**

[Supplier & price]({p['source']}) · [Manufacturer documentation]({p.get('datasheet',p['source'])})
</div>
'''
cards+=f'''<div class="component-card" markdown>
{photo(adapter,160)}
<div class="number">EXTERNAL POWER · PURCHASING CANDIDATE</div>
### GST18A09-P1J
9 V / 2 A desktop supply; input cord sold separately.

**${adapter['price']:.2f} each**

[Supplier & price]({adapter['source']}) · [Datasheet]({adapter['datasheet']})
</div>
</div>

*Product images: manufacturer reference photos via the linked DigiKey listings. Images are representative; confirm suffix, package and dimensions from the datasheet. This sourcing pass does not establish final mounting or team interface approval.*

'''
text=text[:start]+cards+text[end:]
text=text.replace('Current manufacturer pages are linked for verification. Exact orderable packages, supplier quotations and component photographs for every commercial alternative still need a procurement pass; no unverified prices are presented as quotations. Motor and ribbon decisions are deferred until the team confirms them.','')
text=text.replace('complete commercial comparisons with exact prices and photos','complete the remaining alternative-product comparisons and recheck supplier prices before ordering')
component.write_text(text,encoding='utf-8')

# Technical block diagram as editable SVG, with a distinct lane for each channel.
svg=['''<svg xmlns="http://www.w3.org/2000/svg" width="1900" height="1370" viewBox="0 0 1900 1370" role="img" aria-labelledby="title desc"><title id="title">Team 103 detailed two-motor encoder block diagram</title><desc id="desc">Four optical channels pass through pull-up RC nodes, MCP6004 amplifiers and SN74HC14 Schmitt gates into PIC RB0 through RB3. Local fused power is regulated to 5 volts. UART and ribbon mapping are proposed.</desc><defs><marker id="signal" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto"><path d="M0 0L9 3.5L0 7Z" fill="#147b80"/></marker><marker id="power" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto"><path d="M0 0L9 3.5L0 7Z" fill="#b5781e"/></marker></defs><rect width="1900" height="1370" rx="20" fill="#f3f7f6"/><g font-family="Segoe UI,Arial,sans-serif">''']
def txt(x,y,t,size=20,color='#142c3c',bold=False):svg.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{700 if bold else 400}">{html.escape(t)}</text>')
def box(x,y,w,h,title,lines,fill='white',stroke='#bdcdd1',titlecolor='#147b80'):
 svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}" stroke="{stroke}" stroke-width="2"/>');txt(x+16,y+29,title,20,titlecolor,True)
 for i,l in enumerate(lines):txt(x+16,y+58+i*25,l,17)
def line(points,color='#147b80',arrow=True,dash=False):
 svg.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in points)+f'" fill="none" stroke="{color}" stroke-width="3"'+(' stroke-dasharray="8 5"' if dash else '')+(f' marker-end="url(#{"power" if color=="#b5781e" else "signal"})"' if arrow else '')+'/>')
txt(35,47,'Motor encoder subsystem | detailed architecture',32,bold=True)
txt(35,83,'Elijah Koiki • Team 103 • RAS304 • Revision B schematic alignment • 28 October 2026',21,'#526b75')
line([(35,120),(95,120)]);txt(110,126,'Analog / digital signal',17)
line([(470,120),(530,120)],'#b5781e');txt(545,126,'Local power',17)
line([(830,120),(890,120)],dash=True);txt(905,126,'Proposed team interface',17)
svg.append('<rect x="300" y="165" width="1560" height="1095" rx="14" fill="#ffffff" stroke="#91aab2" stroke-width="2" stroke-dasharray="10 6"/>')
txt(325,201,'CUSTOM ENCODER PCB / LOCAL +5 V DOMAIN',20,'#526b75',True)
txt(35,215,'OFF-BOARD SENSORS',18,'#526b75',True)
txt(35,239,'2 disks · 2 A/B pairs',17,'#526b75')
rows=[('E1A','Q1','J2','R2','R3','C4','R4','R5','U2A','U3A','RB0','46','2'),('E1B','Q2','J3','R6','R7','C5','R8','R9','U2B','U3B','RB1','10','4'),('E2A','Q3','J4','R10','R11','C6','R12','R13','U2C','U3C','RB2','9','6'),('E2B','Q4','J5','R14','R15','C7','R16','R17','U2D','U3D','RB3','47','8')]
box(1170,250,310,680,'A1 · PIC18F57Q43',['Curiosity Nano / DM164150'],fill='#eaf3f2')
for i,(name,q,j,rled,rpull,cap,rf,rg,op,gate,pin,edge,out) in enumerate(rows):
 y=280+i*165
 box(35,y,220,115,f'{q} · {name} sensor',['TCST2103 / slot 3.1 mm',f'{j}: LED / SIG / GND'])
 box(340,y,250,115,f'{name}_RAW · TP{4+i}',[f'{rpull}: 4.7 kΩ pull-up',f'{cap}: 1 nF to ground'])
 box(650,y,220,115,f'{op} · MCP6004',[f'{rf}=10 kΩ / {rg}=20 kΩ','Non-inverting gain 1.5'])
 box(930,y,180,115,gate+' · HC14',[f'Output pin {out}','Schmitt + invert'])
 line([(255,y+60),(340,y+60)]);txt(270,y+47,'analog',14,'#147b80')
 line([(590,y+60),(650,y+60)]);line([(870,y+60),(930,y+60)])
 line([(1110,y+60),(1170,y+60)]);txt(1115,y+45,'DIG',14,'#147b80')
 txt(1190,y+62,f'{pin} / edge {edge}',20,bold=True);txt(1190,y+90,name+'_DIG',16,'#526b75')
 txt(42,y+142,f'{rled}: 220 Ω emitter drive ≈17 mA',15,'#8a5b16')
txt(1190,891,'Count A/B transitions;',18);txt(1190,916,'timer → speed estimate',18)
box(1540,440,285,340,'J6 · 2 × 4 ribbon',['PROPOSED / NOT APPROVED','Pin 1: ENC_TX via JP1','Pin 2: ENC_RX','Pin 8: common GND','Pins 3–7: NC in Rev B','No +5 V on ribbon','5 V UART logic, not RS-232'],fill='#fff6e6',stroke='#d5b16e',titlecolor='#8a5b16')
line([(1480,560),(1540,560)],dash=True);txt(1490,537,'TX',15)
line([(1540,620),(1480,620)],dash=True);txt(1490,650,'RX',15)
txt(1538,808,'RC6 / edge 13 → JP1 → TX',16);txt(1538,836,'RX → RC7 / edge 19',16)
box(1540,280,285,115,'TEAM / PC',['Connor: main controller','Walker: motor actuation'],fill='#edf1f6',titlecolor='#476080')
line([(1682,440),(1682,395)],dash=True)
txt(35,990,'Mechanical requirements',20,bold=True)
txt(35,1020,'A/B offset: 90 electrical°',18);txt(35,1048,'4N counts / disk revolution',18);txt(35,1076,'f = slots × shaft RPM / 60',18);txt(35,1104,'Home + gear ratio required',18)
box(340,1000,250,145,'J1 → F1 → U1',['9–12 V center-positive','500 mA fuse → L7805','C1 .33µF / C2 .1µF','C3 10µF output bulk'],fill='#fff6e6',stroke='#d5b16e',titlecolor='#8a5b16')
box(650,1000,450,145,'+5 V REGULATED / COMMON GND',['Sensors + MCP6004 + SN74HC14 + Nano','C8 / C9 / C10: 0.1 µF local bypass','Nano VTG edge 51; VOFF edge 55 → GND','TP1 VIN_FUSED · TP2 +5 V · TP3 GND'],fill='#fff6e6',stroke='#d5b16e',titlecolor='#8a5b16')
line([(590,1072),(650,1072)],'#b5781e')
line([(875,1000),(875,965),(1325,965),(1325,930)],'#b5781e')
box(1170,1000,655,145,'DEBUG / EXPANSION',['RA3 edge 16 → R18 1 kΩ → D2 yellow LED','SW1 / R19 10 kΩ / C11 100 nF → RA4 edge 17','J7: RA0 edge 43 · RA1 edge 44 · +5 V · GND','D1 green + R1 1 kΩ = power indication'],fill='#edf3f5')
txt(340,1190,'RC pole ≈33.9 kHz / τ≈4.7 µs. Amplifier saturation recovery and edge rate require bench testing.',18,'#526b75')
txt(340,1221,'R19/C11 gives nominal 1 ms; the older 10 ms note requires reconciliation. No circuit values changed.',18,'#526b75')
txt(35,1303,'Motor model, disk fit, approved ribbon placement and protocol remain deferred. Diagram is functional architecture, not a fabrication drawing.',19,'#526b75')
txt(35,1338,'Local power block supplies all four sensing lanes. Keep motor drive power and high-current wiring on the driver subsystem.',19,'#526b75')
svg.append('</g></svg>');write('01-Block-Diagram/encoder-detailed-block-diagram.svg',''.join(svg))

block=docs/'01-Block-Diagram/Block-Diagram.md';text=block.read_text(encoding='utf-8')
marker='![Two-motor optical encoder architecture'
pos=text.index(marker)
text=text[:pos]+'''## Detailed signal, pin and power diagram

![Detailed encoder block diagram with four optical channels, filter/amplifier values, PIC input pins, local power, debug and proposed team link](encoder-detailed-block-diagram.png)

*Figure 1. Detailed architecture matched to Revision B. Every motor has an A/B sensor pair; each of the four lanes shows its raw test point, RC values, amplifier unit, Schmitt gate and Nano input. The proposed ribbon allocation is explicitly separated from confirmed board connections.*

[Full-size PNG](encoder-detailed-block-diagram.png){.download} [Editable detailed SVG](encoder-detailed-block-diagram.svg){.download} [All diagram sources ZIP](encoder-block-diagram-source.zip){.download}

## System overview

'''+text[pos:]
text=text.replace('*Figure 1. Two-motor encoder architecture.','*Figure 2. Two-motor encoder architecture.')
block.write_text(text,encoding='utf-8')

# Local CSS additions; keep the established theme and page order intact.
css=docs/'stylesheets/extra.css'
css.write_text(css.read_text()+'''\n/* Product sourcing additions, October 28 */
.component-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem;margin:1rem 0 1.7rem}.component-card{padding:1.2rem;background:#fff;border:1px solid #d8e3e4;border-radius:10px;min-width:0}.component-card>p:first-child{background:white;text-align:center}.component-card img{width:150px;height:140px;object-fit:contain;margin:0 auto .6rem;display:block}.component-card h3{font-size:1rem;margin:.5rem 0}.component-card .number{font-size:.64rem;letter-spacing:.07em;color:#157c83;font-weight:750}.component-card p{font-size:.73rem}.bom-table td:first-child{min-width:10rem;max-width:15rem}.bom-table td img{display:block;width:70px;height:65px;object-fit:contain;background:white;margin:.1rem 0 .45rem}.bom-table code{white-space:normal;overflow-wrap:anywhere}.bom-table td{min-width:4rem}.bom-table .md-typeset__table{display:block}.bom-table td:nth-child(4),.bom-table td:nth-child(5){white-space:nowrap}.bom-table table{width:100%}@media(max-width:650px){.component-cards{grid-template-columns:1fr}}\n''',encoding='utf-8')

appendix=docs/'Appendix/index.md';text=appendix.read_text();text=text.replace('| Component comparisons | Current selections and tradeoffs documented | Complete commercial alternatives, exact unit costs and photos. |','| Component selection / priced BOM | Orderable core parts, photos, unit prices and extended costs added | Complete remaining alternative comparisons; reconfirm quotations and physical fit before ordering. |')
text+='\nOctober 28 sourcing refinement: added a detailed four-channel architecture diagram, local supplier product photos, example manufacturer part numbers, a priced BOM and an external-power purchasing candidate. Prices are dated references; motor and ribbon decisions remain deferred.\n';appendix.write_text(text,encoding='utf-8')
print(json.dumps({'priced_lines':len(parts),'subtotal_usd':str(subtotal),'images_downloaded':len(list(assets.glob('*.jpg')))},indent=2))
