from pathlib import Path
import zipfile,json
repo=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26');d=repo/'docs'
for p in [d/'03-BOM/BOM.md',d/'02-Component-Selection/Component-Selection.md']:
 t=p.read_text(encoding='utf-8').replace('src="../static/parts/','src="../../static/parts/')
 p.write_text(t,encoding='utf-8')
p=d/'01-Block-Diagram'
with zipfile.ZipFile(p/'encoder-block-diagram-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['encoder-block-diagram.svg','encoder-block-diagram.png','encoder-detailed-block-diagram.svg','encoder-detailed-block-diagram.png']:z.write(p/n,n)
# Keep supplier photo provenance with its original URLs and price assumptions.
data=json.loads((d/'03-BOM/encoder-parts-sources.json').read_text(encoding='utf-8'))
assert sum(round(p['price']*p['qty']*100) for p in data['parts'])==3895
assert len(data['parts'])==26
print('BOM quantities and $38.95 sourced subtotal verified; image URLs corrected for rendered page depth.')
