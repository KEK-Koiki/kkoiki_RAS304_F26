import fs from 'node:fs/promises';
import sharp from 'sharp';
import {execFileSync} from 'node:child_process';
const root='C:/Users/elija/Website Repos/kkoiki_RAS304_F26/docs/';
const dir=root+'01-Block-Diagram/';
const s=[];
const esc=t=>t.replaceAll('&','&amp;').replaceAll('<','&lt;');
const text=(x,y,t,size=23,color='#173342',bold=false)=>s.push(`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" font-weight="${bold?700:400}">${esc(t)}</text>`);
const box=(x,y,w,h,lines,color='#ffffff',stroke='#9bb3ba')=>{
s.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="7" fill="${color}" stroke="${stroke}" stroke-width="2"/>`);
lines.forEach((t,i)=>text(x+w/2,y+29+i*29,t,i?21:23,'#173342',i===0));
};
const wire=(points,color='#147b80',arrow=true)=>s.push(`<polyline points="${points.map(p=>p.join(',')).join(' ')}" fill="none" stroke="${color}" stroke-width="3" ${arrow?`marker-end="url(#${color==='#b5781e'?'p':'a'})"`:''}/>`);
s.push('<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1060" viewBox="0 0 1400 1060"><title>Team 103 motor encoder connections</title><desc>Two optical A/B encoders connect through RC filters, a quad op amp and Schmitt gates to PIC RB0 through RB3. Local fused power supplies five volts. A proposed UART link connects to the main board.</desc><defs><marker id="a" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto"><path d="M0 0L8 3.5L0 7Z" fill="#147b80"/></marker><marker id="p" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto"><path d="M0 0L8 3.5L0 7Z" fill="#b5781e"/></marker></defs><rect width="1400" height="1060" fill="#f7faf9"/><g font-family="Arial,sans-serif" text-anchor="middle">');
text(700,49,'Team 103 | Motor Encoder',32,'#173342',true);
text(700,84,'Elijah Koiki - RAS304',23);
s.push('<rect x="280" y="130" width="1080" height="730" rx="10" fill="#ffffff" stroke="#7899a3" stroke-width="2" stroke-dasharray="9 6"/>');
text(1230,158,'Encoder PCB',20,'#56737d');
box(30,180,190,82,['DC supply','9-12 V']);
box(320,180,170,82,['J1 / F1','500 mA']);
box(550,180,200,82,['U1 - L7805','+5 V']);
wire([[220,221],[320,221]],'#b5781e');wire([[490,221],[550,221]],'#b5781e');
wire([[750,221],[1260,221],[1260,285]],'#b5781e',false);
wire([[405,285],[1260,285]],'#b5781e',false);text(900,272,'+5 V',21,'#946215',true);
for(const x of [405,620,850,1160])wire([[x,285],[x,320]],'#b5781e');
box(30,350,190,145,['Motor 1','TCST2103 x2']);
box(30,550,190,145,['Motor 2','TCST2103 x2']);
box(320,320,170,400,['RC filters','4.7k / 1nF'],'#edf5f4');
box(550,320,200,400,['U2 - MCP6004','Op amp x4'],'#edf5f4');
box(810,320,170,400,['U3 - HC14','Schmitt x4'],'#edf5f4');
box(1040,320,280,400,['PIC18F57Q43','Curiosity Nano'],'#e7f0f3');
for(const [y,label,pin] of [[420,'J2-A','RB0'],[470,'J3-B','RB1'],[620,'J4-A','RB2'],[670,'J5-B','RB3']]){
 text(250,y-12,label,17,'#147b80',true);
 for(const [x1,x2] of [[220,320],[490,550],[750,810],[980,1040]])wire([[x1,y],[x2,y]]);
 text(1100,y+7,pin,23,'#173342',true);
}
text(405,551,'x4',27,'#147b80',true);text(650,551,'Gain 1.5',23,'#147b80');
text(895,551,'5 V logic',21,'#147b80');
// The two emitter pairs use the local rail, shown without adding crossing wires.
text(125,745,'+5 V / GND',21,'#946215');
box(320,760,190,68,['SW1'], '#f0f4f5');box(590,760,190,68,['D2 - LED'], '#f0f4f5');
text(1065,707,'RA4',19);text(1150,707,'RA3',19);text(1220,707,'RC6',19);text(1295,707,'RC7',19);
wire([[415,760],[415,740],[1065,740],[1065,720]]);
wire([[1150,720],[1150,837],[685,837],[685,828]]);
text(1000,776,'Debug',18,'#56737d');
box(1050,915,280,100,['J6 - UART*','Main board (Connor)'],'#fff5e4','#c4a265');
wire([[1220,720],[1220,875],[1120,875],[1120,915]]);
wire([[1270,915],[1270,892],[1340,892],[1340,740],[1295,740],[1295,720]]);
text(1165,871,'JP1 / TX',18,'#147b80');text(1354,824,'RX',18,'#147b80');
text(700,1028,'* Proposed: pin 1 TX | pin 2 RX | pin 8 GND',21,'#56737d');
s.push('</g></svg>');
// ASCII SVG source avoids Windows default-encoding damage to labels.
const svg=s.join('');
await fs.writeFile(dir+'encoder-detailed-block-diagram.svg',svg,'utf8');
await sharp(Buffer.from(svg),{density:144}).png().toFile(dir+'encoder-detailed-block-diagram.png');
// Use the same clean drawing wherever the earlier overview was embedded.
await fs.writeFile(dir+'encoder-block-diagram.svg',svg,'utf8');
await fs.copyFile(dir+'encoder-detailed-block-diagram.png',dir+'encoder-block-diagram.png');
let page=execFileSync('C:/Users/elija/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe',['-C','C:/Users/elija/Website Repos/kkoiki_RAS304_F26','show','HEAD:docs/01-Block-Diagram/Block-Diagram.md'],{encoding:'utf8'});
const heading='# Individual Block Diagram';
const a=page.indexOf(heading)+heading.length;const b=page.indexOf('## Signal path and design decisions');
if(a<heading.length||b<a)throw new Error('Expected page sections missing');
page=page.slice(0,a)+`\n\nTwo motors. Four optical channels. One encoder board.\n\n![Motor encoder board connections](encoder-detailed-block-diagram.png)\n\n[Full-size PNG](encoder-detailed-block-diagram.png){.download} [Editable SVG](encoder-detailed-block-diagram.svg){.download} [Source ZIP](encoder-block-diagram-source.zip){.download}\n\n`+page.slice(b);
await fs.writeFile(dir+'Block-Diagram.md',page,'utf8');
console.log('Simple connection diagram written.');
