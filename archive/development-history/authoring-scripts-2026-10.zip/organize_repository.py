from pathlib import Path
import re,json,shutil,zipfile,xml.dom.minidom

workspace=Path(__file__).resolve().parent
repo=Path('C:/Users/elija/Website Repos/kkoiki_RAS304_F26')
docs=repo/'docs'
def write(path,text):
 p=repo/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def move(source,destination):
 src=(repo/source).resolve();dst=(repo/destination).resolve()
 if not src.is_relative_to(repo.resolve()) or not dst.is_relative_to(repo.resolve()):raise ValueError('Move outside repository')
 if src.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(src),str(dst))

# Keep original examples recoverable but outside the published source tree.
examples=['01-Block-Diagram/individual-block-diagram.png','02-Component-Selection/image1.png','02-Component-Selection/image3.png','03-BOM/BOM-Screenshot.png','04-Schematic/ExampleSchematic.pdf','04-Schematic/Screenshot.png','04-Schematic/dummyZip.zip','05-Power-Budget/PowerBudgetExample.pdf','05-Power-Budget/PowerBudgetExample.xlsx','05-Power-Budget/budgetPg1.png','05-Power-Budget/budgetPg2.png','05-Power-Budget/budgetPg3.png','05-Power-Budget/power-budject-new','Appendix/Image01.jpg','Appendix/ImageShowcase.png','Appendix/another-subfile.md','Appendix/basic-markdown-examples.md','Appendix/charts.md','Appendix/esp-32-table.md','static/logo.png','static/logo.svg','static/logo304.svg','static/package.json','static/package-lock.json','javascripts/mathjax.js']
for f in examples:move('docs/'+f,'archive/course-template/docs/'+f)
write('archive/README.md','''# Archived course-template material

Original examples are retained in `course-template/docs/` for reference. They are not current project content and are not published by MkDocs. The current website uses the numbered folders under the root `docs/` directory.

Earlier authoring scripts are preserved in the development-history ZIP. They record superseded drafts and machine-specific workflows; do not run them to edit the current site. Use the focused tools in `tools/` instead. Git history also retains every published revision.
''')

# Pretty-print existing CSS without changing selectors, declarations or cascade order.
css=(docs/'stylesheets/extra.css').read_text(encoding='utf-8')
def rules(text):
 text=re.sub(r'/\*.*?\*/','',text,flags=re.S);result=[];start=0;depth=0;quote=None
 for i,c in enumerate(text):
  if quote:
   if c==quote and (i==0 or text[i-1]!='\\'):quote=None
  elif c in ['"',"'"]:quote=c
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:result.append(text[start:i+1].strip());start=i+1
 return [r for r in result if r]
def pretty(rule,indent=''):
 head,body=rule.split('{',1);body=body[:-1]
 if head.strip().startswith('@'):
  return indent+head.strip()+' {\n'+'\n\n'.join(pretty(r,indent+'  ') for r in rules(body))+'\n'+indent+'}'
 declarations=[s.strip() for s in body.split(';') if s.strip()]
 return indent+head.strip()+' {\n'+'\n'.join(indent+'  '+d.replace(':',': ',1)+';' for d in declarations)+'\n'+indent+'}'
groups={n:[] for n in ['base','overview','responsive','print','products','layout']}
allrules=rules(css)
for r in allrules:
 selector=r.split('{',1)[0]
 if 'min-width:76.25em' in selector or selector.startswith('.bom-table table:not') or selector.startswith('.bom-table td:nth-child(6)') or selector.startswith('.bom-table td:nth-child(2)'):key='layout'
 elif '.component-' in selector or '.bom-table' in selector or 'max-width:650px' in selector:key='products'
 elif selector.startswith('@media print'):key='print'
 elif selector.startswith('@media'):key='responsive'
 elif selector.startswith(('.eyebrow','.hero','.meta','.cards','.card','.stat','.caption','.status')):key='overview'
 else:key='base'
 groups[key].append(r)
for key,rs in groups.items():write('docs/stylesheets/'+key+'.css','/* '+key.title()+' styles. See EDITING.md before changing cascade order. */\n\n'+'\n\n'.join(pretty(r) for r in rs))
write('docs/stylesheets/extra.css','''/* Public stylesheet entry point. Keep this import order. */
@import url("base.css");
@import url("overview.css");
@import url("responsive.css");
@import url("print.css");
@import url("products.css");
@import url("layout.css");
''')
# Save the exact pre-refactor rules outside docs for a semantic comparison.
(workspace/'organization-original.css').write_text(css,encoding='utf-8')

# Structured purchasing data and small presentation templates.
record=json.loads((docs/'03-BOM/encoder-parts-sources.json').read_text(encoding='utf-8'))
write('data/bom/parts.json',json.dumps(record,indent=2,ensure_ascii=False))
bom=(docs/'03-BOM/BOM.md').read_text(encoding='utf-8')
tables=list(re.finditer(r'<div class="bom-table" markdown>.*?</div>',bom,re.S))
if len(tables)!=4:raise ValueError('Expected four BOM tables')
tokens=['CORE_TABLE','PASSIVE_TABLE','INTERFACE_TABLE','ADAPTER_TABLE']
for match,key in reversed(list(zip(tables,tokens))):bom=bom[:match.start()]+'{{'+key+'}}'+bom[match.end():]
for price,key in [('38.95','SUBTOTAL'),('20.94','CORE_TOTAL'),('8.90','PASSIVE_TOTAL'),('9.11','INTERFACE_TOTAL'),('53.05','WITH_ADAPTER')]:bom=bom.replace('$'+price,'${{'+key+'}}')
a=bom.index('## Fit, sourcing and assembly notes')+len('## Fit, sourcing and assembly notes');b=bom.index('## Items still requiring')
bom=bom[:a]+'\n\n{{FIT_NOTES}}\n\n'+bom[b:]
write('templates/bom/page.md',bom)
component=(docs/'02-Component-Selection/Component-Selection.md').read_text(encoding='utf-8')
a=component.index('<div class="component-cards" markdown>');b=component.index('*Product images:',a)
write('templates/components/cards.html',component[a:b])

# Editable diagram master plus raw engineering sources, kept out of web navigation.
raw=(docs/'01-Block-Diagram/encoder-detailed-block-diagram.svg').read_text(encoding='utf-8')
master=xml.dom.minidom.parseString(raw).toprettyxml(indent='  ')
write('design/diagrams/encoder.svg',master)
for name in ['Team103_Encoder_EK.kicad_pro','Team103_Encoder_EK.kicad_sch','EK.kicad_sym','sym-lib-table','REVIEW_AND_TESTS.txt','erc_after.json']:
 target=repo/'design/ecad/encoder-revb'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(workspace/'Encoder_Review'/name,target)
write('design/README.md','''# Editable engineering sources

- `diagrams/encoder.svg`: the readable, editable master for the approved simple connection diagram. Open it in Inkscape or another SVG editor; labels and geometry can also be edited as XML.
- `ecad/encoder-revb/Team103_Encoder_EK.kicad_pro`: open in KiCad with the neighboring symbol library and library table. The reviewed electrical source has not been altered by repository organization.
- Published PNG/PDF/ZIP exports remain beside their assignment pages in `docs/` to preserve existing URLs.

After editing the diagram, run `npm run diagram:export`. It refreshes both existing public image aliases and the source ZIP. No web page text is overwritten. See `EDITING.md` for schematic export instructions.
''')

# Provenance: retain all one-time scripts, without exposing them as active commands.
history=repo/'archive/development-history';history.mkdir(parents=True,exist_ok=True)
names=['build_website.py','refine_website.py','finalize_refinements.py','polish_refinements.py','research_parts.py','parts-catalog.json','sourced-parts.json','render-detail.mjs','simplify_diagram.mjs','power-budget.mjs','verify_website.py']
with zipfile.ZipFile(history/'authoring-scripts-2026-10.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in names:
  if (workspace/n).exists():z.write(workspace/n,n)

# Keep the optional advanced spreadsheet builder, using portable paths.
p=(workspace/'power-budget.mjs').read_text(encoding='utf-8')
p=p.replace("const repo='C:/Users/elija/Website Repos/kkoiki_RAS304_F26';", "import { fileURLToPath } from 'node:url';\nconst repo=fileURLToPath(new URL('../../', import.meta.url)).replaceAll('\\\\','/').replace(/\\/$/,'');")
p=p.replace("const output='C:/Users/elija/OneDrive/Documents/ChatGPT/RAS304 Main project/outputs/power-budget';", "const output=repo+'/_artifacts/power-budget';")
write('tools/power-budget/build.mjs',p)
write('tools/power-budget/README.md','''# Power budget

For a quick edit, open `docs/05-Power-Budget/Team103_Encoder_Power_Budget.xlsx` in Excel and update the table/explanation in `Power-Budget.md`. Inputs and their status are recorded in `budget-inputs.json` beside them.

`build.mjs` is the optional reproducible authoring source. It requires the Codex `@oai/artifact-tool` runtime (not a public npm dependency). It reads the existing JSON and writes a candidate workbook/preview under `_artifacts/power-budget/`; it does not silently replace the published workbook. Review and copy the candidate only after checking the calculations and layout. Ordinary website editing and builds do not need this library.
''')
write('.gitignore','''# Generated website and local dependencies
site/
node_modules/
docs/static/node_modules/
_artifacts/
__pycache__/
.venv/
*.log
''')
print('Repository content and sources organized; public page paths retained.')
